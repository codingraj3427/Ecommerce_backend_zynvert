const Stripe = require("stripe");
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const { Order, OrderItem } = require("../models/postgres");

const FRONTEND_URL = process.env.FRONTEND_URL;

exports.createCheckoutSession = async (req, res) => {
  try {
    const userId = req.user.uid;

    // ✅ FIX: read both values
    const { cartItems, shippingAddress } = req.body;

    if (!Array.isArray(cartItems) || cartItems.length === 0) {
      return res.status(400).json({ message: "Cart is empty" });
    }

    if (!shippingAddress) {
      return res.status(400).json({ message: "Shipping address missing" });
    }

    /* ---------------- CREATE ORDER ---------------- */
    const order = await Order.create({
      user_id: userId,
      total_amount: cartItems.reduce(
        (sum, i) => sum + i.price * i.quantity,
        0
      ),
      status: "Pending Payment",
    });

    /* ---------------- ORDER ITEMS ---------------- */
    for (const item of cartItems) {
      await OrderItem.create({
        order_id: order.order_id,
        product_id: item.productId,
        quantity: item.quantity,
        unit_price: item.price,
      });
    }

    /* ---------------- STRIPE LINE ITEMS ---------------- */
    const lineItems = cartItems.map((item) => ({
      price_data: {
        currency: "inr",
        product_data: {
          name: item.name,
          images: item.image ? [item.image] : [],
        },
        unit_amount: Math.round(item.price * 100),
      },
      quantity: item.quantity,
    }));

    /* ---------------- STRIPE SESSION ---------------- */
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],

      line_items: lineItems,

      // ✅ Stripe-correct address handling
      shipping_address_collection: {
        allowed_countries: ["IN"],
      },

      customer_email: req.user.email,

      metadata: {
        order_id: order.order_id,
        user_id: userId,
      },

      success_url: `${FRONTEND_URL}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${FRONTEND_URL}/cart`,
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error("Stripe Checkout Error:", err);
    res.status(500).json({ message: "Stripe error" });
  }
};

exports.confirmPayment = async (req, res) => {
  try {
    const userId = req.user.uid;
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({ message: "Session ID missing" });
    }

    // 🔍 Verify session with Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (session.payment_status !== "paid") {
      return res.status(400).json({ message: "Payment not completed" });
    }

    // ✅ Mark latest order as PAID
    await Order.update(
      { status: "Paid" },
      { where: { user_id: userId, status: "Pending Payment" } }
    );

    // 🧹 CLEAR CART
    await CartItem.destroy({ where: { user_id: userId } });

    res.json({ success: true });
  } catch (err) {
    console.error("Confirm payment error", err);
    res.status(500).json({ message: "Payment confirmation failed" });
  }
};

