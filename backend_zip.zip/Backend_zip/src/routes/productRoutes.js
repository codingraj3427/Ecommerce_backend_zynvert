const express = require("express");
const router = express.Router();
const productController = require("../controllers/productController");

router.get("/", productController.getAllProducts);
router.get("/categories", productController.getCategories);
router.get("/featured", productController.getFeaturedProducts);
router.get("/:id", productController.getProductById);
router.get("/display/:flag", productController.getProductsByDisplayFlag);
router.get("/search", productController.searchProducts);

module.exports = router;
